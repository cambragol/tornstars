// save_type.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>


void ParseName(char *name);

double PrintGiant(FILE * out, char *name, char *parent, double orbit, double rot);
void PrintMoon(FILE * out, char *name, char *parent, double orbit, double rot, double radius);
double PrintPlanet(FILE * out, char *name, char *parent, double orbit, double rot);

void PrintStation(FILE * out, char *name, char *parent, 
				  double orbit, double rot, int faction, 
				  int type, int model, FILE * finiout, int count, 
				  char * fac_name);

void PrintStar(FILE * out, char *name, char *parent);
void PrintBelt(FILE * out, char *name, char *parent, double orbit, double rot);
void PrintCenter(FILE * out, char *name);
double rand_size(double lower, double upper);
int rand_int( int upper);

int NameToFaction(char * name);
int NameToStation(char * name);
int NameToStationType(char * name);


int HabTypeToDefType(int type);
int HabTypeToDef(int type);


/* 
	This global entity acts as symbol table
	and intermediate form for all objects in
	geography. When the *.csv file is done
	being parsed, this array is written to file
	to form the *.map file.

  */


int main(int argc, char* argv[])
{ 
	FILE *finput;
	FILE *foutput;
	FILE *fouttext;
	FILE *foutini;

	char line [2048];
	char * ptoken;


	char name[1024];
	char station[1024];
	char faction[1024];

	char planet[1024];
	char moon[1024];
	char file_name[1024];


	double station_orbit = 0.25;
	double station_rot = 30.0;

	double planet_orbit = 0.25;
	double planet_rot = 30.0;
	double planet_radius = 12e6;

	double moon_orbit = 0.25;
	double moon_rot = 30.0;

	char station_parent[1024];
	char planet_parent[1024];
	char moon_parent[1024];
	char center_name[1024];

	int i, entries;
	int fac, type, model;

	int station_count = 0;

	if (argc != 2){ 
		printf("Usage: save_type <input spreadsheet name>\n");
		return 1;
	}

	// Open the input file
	finput = fopen(argv[1],"r");

	if (NULL == finput){ 
		printf("Error: trying to open input file %s\n",argv[1]);
		return 1;
	}

	foutput = NULL;
	fouttext = NULL;

	srand(1);

	// While not out of lines
	while (NULL != fgets(line,2048,finput)){ 

		ptoken = strtok(line, " \t,");
		//printf("token :%s:\n",ptoken);

		if (0 == strcmp("Giant",ptoken)){ 
			ParseName(name);

			planet_radius = PrintGiant(foutput, name, planet_parent, planet_orbit, planet_rot);

			// reset the moon orbit rotation
			// reset the moon orbit distance
			// reset the moon parent
			moon_orbit = 0.25;
			moon_rot = planet_rot;
			strcpy(moon_parent,name);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
			station_orbit = 0.15;
			station_rot = 0.0;
			strcpy(station_parent,name);

			// increment planet distance and rotation
			planet_orbit *=1.25;
			planet_rot += 30.0;
			if (planet_rot >= 360)
				planet_rot = 0;

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

		}else if (0 == strcmp("Station",ptoken)){ 
			ParseName(name);

			ParseName(station);

			ParseName(faction);

			fac = NameToFaction(faction);

			type = NameToStationType(station);

			model = NameToStation(station);

			PrintStation(foutput, name, station_parent, station_orbit, 
					station_rot, fac, type, model, foutini, station_count, faction);

			// increment puts stations in tri balance. stations end up
			// on near opposite sides of planet. with uneven
			// value, they should never overlap.
			station_rot += 127.0;
			station_rot = fmod(station_rot, 360.0);

			station_count++;

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

		}else if (0 == strcmp("Planet",ptoken)){ 
			ParseName(name);

			planet_radius = PrintPlanet(foutput, name, planet_parent, planet_orbit, planet_rot);

			// reset the moon orbit rotation
			// reset the moon orbit distance
			// reset the moon parent
			moon_orbit = 0.4;
			moon_rot = planet_rot;
			strcpy(moon_parent,name);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
			station_orbit = 0.15;
			station_rot = 0.0;
			strcpy(station_parent,name);

			// increment planet distance and rotation
			planet_orbit *=1.25;
			planet_rot += 30.0;
			planet_rot = fmod(planet_rot, 360.0);

			fprintf(fouttext,"%s,\"%s\"\n",name,name);
			
		}else if (0 == strcmp("Belt", ptoken)){ 
			ParseName(name);

			PrintBelt(foutput, name, planet_parent, planet_orbit, planet_rot);

			// reset the moon orbit rotation
			// reset the moon orbit distance
			// reset the moon parent
			moon_orbit = 0.25;
			moon_rot = planet_rot;
			strcpy(moon_parent,name);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
			station_orbit = 0.13;
			station_rot = planet_rot;
			strcpy(station_parent,name);

			// increment planet distance and rotation
			planet_orbit *=1.25;
			planet_rot += 30.0;
			if (planet_rot >= 360)
				planet_rot = 0;

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

		}else if (0 == strcmp("Star", ptoken)){ 
			ParseName(name);

			PrintStar(foutput, name, center_name);

			// reset the moon orbit rotation
			// reset the moon orbit distance
			// reset the moon parent
			moon_orbit = 0.25;
			moon_rot = 0.0;
			strcpy(moon_parent,name);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
			station_orbit = 0.25;
			station_rot = 0.0;
			strcpy(station_parent,name);

			// reset planet parent
			// reset planet orbits
			// reset planet rotation
			planet_orbit = 0.4;
			planet_rot = 0.0;
			strcpy(planet_parent, name);			

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

		}else if (0 == strcmp("Moon", ptoken)){ 
			ParseName(name);

			PrintMoon(foutput, name, moon_parent, moon_orbit, moon_rot, planet_radius);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
			station_orbit = 0.15;
			station_rot = 0.0;
			strcpy(station_parent,name);

			// increment planet distance and rotation
			moon_orbit +=0.23;
			moon_rot += 30.0;
			if (moon_rot>= 360)
				moon_rot = 0;

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

		}else if (0 == strcmp("Center", ptoken)){
			ParseName(name);




			printf("New System :%s:\n",name);
			// Open a new output file.
			// Close the current output file

			if (NULL != foutput){ 
				fclose(foutput);
				fclose(fouttext);
				fclose(foutini);
			}

			strcpy(file_name,name);
			strcat(file_name,".csv");

			foutput = fopen(file_name,"w");

			if (NULL == foutput){ 
				printf("Error: trying to open output file %s\n",file_name);
				return 1;
			}
			
			strcpy(file_name,name);
			strcat(file_name,".txt");

			fouttext = fopen(file_name,"w");

			if (NULL == foutput){ 
				printf("Error: trying to open output text file %s\n",file_name);
				return 1;
			}

			strcpy(file_name,name);
			strcat(file_name,".ini");

			foutini = fopen(file_name,"w");

			if (NULL == foutini){ 
				printf("Error: trying to open output ini file %s\n",file_name);
				return 1;
			}

			fprintf(foutini,"\n\n[starting_stations]\n\n");

			// every system restarts the station count for ini file.
			station_count = 0;

			strcpy(file_name,name);
			strcat(file_name,"_center");

			fprintf(foutput,"Center,%s,0,0,0,1,0,0,0,0,,,,\n",file_name);
			strcpy(center_name,file_name);

			// Just because there might not be a new star, we reset
			// everything here. The star will recreate, if 
			// it needs to.

			// reset the moon orbit rotation
			// reset the moon orbit distance
			// reset the moon parent
			moon_orbit = 0.25;
			moon_rot = 0.0;
			strcpy(moon_parent,name);

			// reset the station parent
			// reset the station distance
			// reset the station rotation
		
			station_orbit = 0.25;
			station_rot = 0.0;
			strcpy(station_parent,name);

			// reset planet parent
			// reset planet orbits
			// reset planet rotation
			planet_orbit = 0.4;
			planet_rot = 0.0;
			strcpy(planet_parent, name);

			fprintf(fouttext,"%s,\"%s\"\n",center_name,name);

		}else if (0 == strcmp("Lpoint", ptoken)){ 
			ParseName(name);

			fprintf(fouttext,"%s,\"%s\"\n",name,name);

			ParseName(planet);

			ParseName(moon);

			// Read the number of entries
			ptoken = strtok(NULL," \t,");
			sscanf(ptoken,"%d",&entries);

			fprintf(foutput,"Lpoint,%s,%s,%s,%d,",name,planet,moon,entries);

			for (i=0;i<entries;++i){ 
				ParseName(name);
				fprintf(foutput,"%s,",name);
			}

			fprintf(foutput,",,,,\n");


		}
	}
	// Close input
	fclose(finput);

	// Close output
	fclose(foutput);

	return 0;
}



void ParseName(char * name)
{ 
	char temp[1024];
	char * ptoken;
	int length, i;

	// finds name, but has white space lead and trail.
	ptoken = strtok(NULL, ",");

	// get the tokenizer out of the equation.
	strcpy(temp,ptoken);
	ptoken = temp;

	// find lead without space, and skip
	//lead = strspn(ptoken," ");
	//ptoken += lead;

	length = strlen(ptoken);
	for (i=0;i<length;i++,ptoken++)
	{ 
		if (!isspace(*ptoken)){ 
			break;
		}
	}
	
	length = strlen(ptoken);

	for (i=length-1;i>0;--i){ 
		if (!isspace(ptoken[i])){ 
			strncpy(name,ptoken,i+1);
			name[i+1]=0;
			//printf("Name :%s: %d\n",name,i);
			return;
		}
	}

	name[0]=0;
}

//type body	name	parent	dist	lat	long	roll	pitch	yaw	y_scale	radius	body type	pop	texture	tex 1	tex 2	red1	green	blue 	red2	green 	blue	red 3	green 	blue	cloud tex	rings	cloud opacity
//Body	Al Qilaal	Aleppo	7.00E+10	0	0	0	0	0	1	6.00E+07	4	0	2	1	1	127	116	96	127	111	82	127	116	96	0	5	255

double PrintGiant(FILE * out, char *name, char *parent, double orbit, double rot)
{ 
	int tex1, tex2;
	double radius;

	// Calculate the giant size.
	radius = rand_size(25e6,100e6);

	tex1 = rand_int(12);
	tex2 = rand_int(12);

	fprintf(out,"\nBody,%s,%s,%f,%f,0,1,0,0,0,%f,4,0,2,%d,%d,255,255,255,0,0,0,127,116,96,0,5,255,\n",
			name, parent,orbit*1.0e11,rot, radius, tex1, tex2);

	return radius;
}

void PrintMoon(FILE * out, char *name, char *parent, double orbit, double rot, double radius)
{ 
	double moon;
	int tex1, tex2;

	// Calculate the moon max size, clamp at quarter planet, or 2 earths.
	moon = radius/4.0;
	if (moon>12e6)
		moon = 12e6;

	moon = rand_size(250000,moon);

	tex1 = rand_int(31);
	tex2 = 31 + rand_int(22);

	// Set a cloud texture if the planet is 70% of earth or larger.

	fprintf(out, "Body,%s,%s,%f,%f,0,1,0,0,0,%f,3,0,1,%d,%d,255,255,255,0,0,0,127,44,34,255,0,0,\n",
		name, parent, orbit*1.0e9,rot,moon,tex1, tex2);
}

double PrintPlanet(FILE * out, char *name, char *parent, double orbit, double rot)
{ 
//Body	Qataar	Aleppo	1.00E+11	30	0	0	0	0	1	5.00E+06	3	0	1	1	1	99	46	40	120	145	14	127	44	34	255	0	0

	double radius;
	int tex1, tex2;

	// Calculate the planet size. 
	radius = rand_size(2e6,12e6);

	tex1 = rand_int(31);
	tex2 = rand_int(54);

	// Set a cloud texture if the planet is 70% of earth or larger.

	fprintf(out, "\nBody,%s,%s,%f,%f,0,1,0,0,0,%f,2,0,1,%d,%d,255,255,255,0,0,0,127,44,34,255,0,0,\n",
		name, parent, orbit*1.0e11,rot, radius, tex1, tex2);

	return radius;
}
/*
[starting_stations]
name[0]="Fonseka Foundation HQ"
parent_body[0]="Brentano"
orbital_distance[0]=15000000.000000
orbital_angle_around[0]=0.000000
orbital_angle_above[0]=0.000000
type[0]=45
;template[0]=17
faction[0]="Fonsenka"
defense[0]="4"
defense_type[0]="5"
*/
void PrintStation(FILE * out, char *name, char *parent, 
				  double orbit, double rot, int faction, 
				  int type, int model, FILE * finiout, int count, 
				  char * fac_name)
{
	fprintf(out, "Station,%s,%s,%f,%f,0,1,0,0,0,0.00E+00,%d,%d,%d,10,\n",
			name, parent, orbit*1.0e8, rot, model, type, 0);

	fprintf(finiout,"name[%d]=\"%s\"\n", count, name);
	fprintf(finiout,"parent_body[%d]=\"%s\"\n", count, parent);
	fprintf(finiout,"template[%d]=%d\n", count, model);
	fprintf(finiout,"orbital_distance[%d]=%f\n",count,orbit*1.0e8);
	fprintf(finiout,"orbital_angle_around[%d]=%f\n",count,rot);
	fprintf(finiout,"orbital_angle_above[%d]=%f\n",count,0);
	fprintf(finiout,"type[%d]=%d\n", count, type);

	fprintf(finiout,"faction[%d]=\"F_%s\"\n", count, fac_name);

	fprintf(finiout,"defense[%d]=%d\n", count,HabTypeToDef(type));
	fprintf(finiout,"defense_type[%d]=%d\n", count,HabTypeToDefType(type));
	fprintf(finiout,"hidden[%d]=0\n", count);
	fprintf(finiout,"destroyed[%d]=0\n", count);
	fprintf(finiout,"visible[%d]=1\n", count);
	fprintf(finiout,"\n\n\n\n");
}

void PrintStar(FILE * out, char *name, char *parent)
{ 
	fprintf(out, "\nStar,%s,%s,0,0,0,1,0,0,0,5.00E+06,5\n",
		name, parent);

}


void PrintBelt(FILE * out, char *name, char *parent, double orbit, double rot)
{ 
	fprintf(out, "\nBelt,%s,%s,%f,%f,0,1,0,0,0,%f,3,0,1,1,1,99,46,40,120,145,14,127,44,34,255,0,0,\n",
			name, parent, orbit*1.0e11,rot,orbit*1.0e11);
}

void PrintCenter(FILE * out, char *name)
{ 
	fprintf(out,"Center,%s,\n",name);
}


double rand_size(double lower, double upper)
{ 
	int temp;
	double value;

	temp = rand();

	value = (temp*(upper-lower))/(double)RAND_MAX;
	value += lower;

	return value;
}

int rand_int( int upper)
{
	int temp;

	temp = rand();
	temp = (temp*upper)/RAND_MAX;

	return temp;
}


int NameToFaction(char * name)

{ 
	if (0==strcmp(name,"Independent")) { return 1;
	}else if (0==strcmp(name,"Leung")) { return 2; 
}else if (0==strcmp(name,"Enavy")) { return 3; 
}else if (0==strcmp(name,"Underworld")) { return 4; 
}else if (0==strcmp(name,"III")) { return 5; 
}else if (0==strcmp(name,"Emerald")) { return 6;
}else if (0==strcmp(name,"ANavy")) { return 7;

}else if (0==strcmp(name,"Khalilistan")) { return 9;
}else if (0==strcmp(name,"Royalguard")) { return 10;
}else if (0==strcmp(name,"Hasim")) { return 11;
}else if (0==strcmp(name,"Karim")) { return 12;
}else if (0==strcmp(name,"Junkers")) { return 13;
}else if (0==strcmp(name,"Mansur")) { return 14;
}else if (0==strcmp(name,"Mustapha")) { return 15;
}else if (0==strcmp(name,"NSOLaPlace")) { return 16;
}else if (0==strcmp(name,"UTulun")) { return 17;
}else if (0==strcmp(name,"Yezhid")) { return 18;
}else if (0==strcmp(name,"Yezhidsec")) { return 19;
}else if (0==strcmp(name,"Corliss")) { return 20;
// Player
}else if (0==strcmp(name,"CDF")) { return 22;
}else if (0==strcmp(name,"CMC")) { return 23;
}else if (0==strcmp(name,"CMCSec")) { return 24;
}else if (0==strcmp(name,"Aikenites")) { return 25;
}else if (0==strcmp(name,"Archangels")) { return 26;
}else if (0==strcmp(name,"Azran")) { return 27;
}else if (0==strcmp(name,"Jardin")) { return 28;
}else if (0==strcmp(name,"Dragons")) { return 29;
}else if (0==strcmp(name,"Brethren")) { return 30;
}else if (0==strcmp(name,"Chavez")) { return 31;
}else if (0==strcmp(name,"Doran")) { return 32;
}else if (0==strcmp(name,"Droznic")) { return 33;
}else if (0==strcmp(name,"EtCom")) { return 34;
}else if (0==strcmp(name,"Whind")) { return 35;
}else if (0==strcmp(name,"Fist")) { return 36;
}else if (0==strcmp(name,"Network54")) { return 37;
}else if (0==strcmp(name,"Melman")) { return 38;
}else if (0==strcmp(name,"StellarNet")) { return 39;
// Wordsworth
}else if (0==strcmp(name,"Fonseka")) { return 41;
}else if (0==strcmp(name,"Gargoyles")) { return 42;
}else if (0==strcmp(name,"Golliger")) { return 43;
}else if (0==strcmp(name,"UCP")) { return 44;
}else if (0==strcmp(name,"Grinnel")) { return 45;
}else if (0==strcmp(name,"Lindevaal")) { return 46;
}else if (0==strcmp(name,"Markus")) { return 47;
}else if (0==strcmp(name,"Mesa")) { return 48;
}else if (0==strcmp(name,"Pimental")) { return 49;
}else if (0==strcmp(name,"Saffron")) { return 50;
}else if (0==strcmp(name,"Lomax")) { return 51;
}else if (0==strcmp(name,"Scavengers")) { return 52;
}else if (0==strcmp(name,"Paramed")) { return 53;
}else if (0==strcmp(name,"Takanan")) { return 54;
}else if (0==strcmp(name,"Neutral")) { return 0;
}

	return 8; // Invalid
}

int NameToStation(char * name)

{ 


	if (0==strcmp(name,"WaterMine")){return 0;
	}else if (0==strcmp(name,"OrganicsMine")){return 22;
	}else if (0==strcmp(name,"InorganicsMine")){return 24;
	}else if (0==strcmp(name,"BiomassMine")){return 0;
	}else if (0==strcmp(name,"CommonMetalsMine")){return 24;
	}else if (0==strcmp(name,"RareMetalsMine")){return 20;
	}else if (0==strcmp(name,"ExoticMetalsMine")){return 20;
	}else if (0==strcmp(name,"RadioactivesMine")){return 22;
	}else if (0==strcmp(name,"FusionableGasesMine")){return 0;
	}else if (0==strcmp(name,"NeutroniumMine")){return 22;
        
	}else if (0==strcmp(name,"WaterProc")){return 1;
	}else if (0==strcmp(name,"OrganicsProc")){return 1;
	}else if (0==strcmp(name,"InorganicsProc")){return 1;
	}else if (0==strcmp(name,"BiomassProc")){return 1;
	}else if (0==strcmp(name,"CommonMetalsProc")){return 1;
	}else if (0==strcmp(name,"RareMetalsProc")){return 1;
	}else if (0==strcmp(name,"ExoticMetalsProc")){return 1;
	}else if (0==strcmp(name,"RadioactivesProc")){return 1;
	}else if (0==strcmp(name,"FusionableGasesProc")){return 1;
	}else if (0==strcmp(name,"NeutroniumProc")){return 1;
        

	}else if (0==strcmp(name,"HeavyMan")){return 5;
	}else if (0==strcmp(name,"BiologicalMan")){return 5;
	}else if (0==strcmp(name,"WetwareMan")){return 5;
	}else if (0==strcmp(name,"HiTechMan")){return 5;
	}else if (0==strcmp(name,"ElectronicsMan")){return 5;
	}else if (0==strcmp(name,"WeaponsMan")){return 5;
	}else if (0==strcmp(name,"PharmaceuticalsMan")){return 5;
	}else if (0==strcmp(name,"PlasticsMan")){return 5;
	}else if (0==strcmp(name,"FusionReactorsMan")){return 5;
	}else if (0==strcmp(name,"EnergyCellsMan")){return 5;
	}else if (0==strcmp(name,"StationFabricationMan")){return 5;
	}else if (0==strcmp(name,"LuxuriesMan")){return 5;
        
	}else if (0==strcmp(name,"BioBomber")){return 32;
        
	}else if (0==strcmp(name,"Shipyard")){return 7;        
	}else if (0==strcmp(name,"Waystation")){return 7;

	}else if (0==strcmp(name,"Research")){return 6;
	}else if (0==strcmp(name,"MedicalResearch")){return 19;
	}else if (0==strcmp(name,"BlackResearch")){return 19;
	}else if (0==strcmp(name,"SensitiveResearch")){return 19;

	}else if (0==strcmp(name,"HQ")){return 17;
        
	}else if (0==strcmp(name,"AgSettlement")){return 2;
	}else if (0==strcmp(name,"Resort")){return 2;
	}else if (0==strcmp(name,"LuxuryResort")){return 2;
        
	}else if (0==strcmp(name,"Medical")){return 3;

	}else if (0==strcmp(name,"SecurityStation")){return 10;
	}else if (0==strcmp(name,"Fortress")){return 14;
        
	}else if (0==strcmp(name,"MercenaryBase")){return 14;
        
	}else if (0==strcmp(name,"Warehousing")){return 8;
	}else if (0==strcmp(name,"Entertainment")){return 11;
        
	}else if (0==strcmp(name,"Settlement")){return 30;
	}else if (0==strcmp(name,"PoliceBase")){return 36;


	}else if (0==strcmp(name,"DefenceDock")){return 15;
        
	}else if (0==strcmp(name,"NavalAcademy")){return 6;
	}else if (0==strcmp(name,"NavalTraining")){return 6;

	}else if (0==strcmp(name,"MarineBarracks")){return 6;
        
	}else if (0==strcmp(name,"NavalResearch")){return 19;
        
	}else if (0==strcmp(name,"SupplyDepot")){return 8;


        
	}else if (0==strcmp(name,"FTLArray")){return 18;

	}else if (0==strcmp(name,"STLTran")){return 12;


	}else if (0==strcmp(name,"SystemAdmin")){return 9;

	}else if (0==strcmp(name,"University")){return 6;

	}else if (0==strcmp(name,"PirateBase")){return 16;
	}else if (0==strcmp(name,"PirateCove")){return 20;

	}else if (0==strcmp(name,"PirateOutpost")){return 20;

	}else if (0==strcmp(name,"Casino")){return 11;

	}else if (0==strcmp(name,"Religious")){return 2;


	}else if (0==strcmp(name,"Habitat")){return 3;

	}else if (0==strcmp(name,"BoxTown")){return 4;

	}else if (0==strcmp(name,"JumpAccel")){return 29;
        
	}else if (0==strcmp(name,"Transfer")){return 0;}

	printf("Error: invalid station type n->s: %s\n",name);
	return 34;
}


int NameToStationType(char * name)

{ 
	if (0==strcmp(name,"WaterMine")){return 2;
	}else if (0==strcmp(name,"OrganicsMine")){return 3;
	}else if (0==strcmp(name,"InorganicsMine")){return 4;
	}else if (0==strcmp(name,"BiomassMine")){return 5;
	}else if (0==strcmp(name,"CommonMetalsMine")){return 6;
	}else if (0==strcmp(name,"RareMetalsMine")){return 7;
	}else if (0==strcmp(name,"ExoticMetalsMine")){return 8;
	}else if (0==strcmp(name,"RadioactivesMine")){return 9;
	}else if (0==strcmp(name,"FusionableGasesMine")){return 10;
	}else if (0==strcmp(name,"NeutroniumMine")){return 53;
        
	}else if (0==strcmp(name,"WaterProc")){return 11;
	}else if (0==strcmp(name,"OrganicsProc")){return 12;
	}else if (0==strcmp(name,"InorganicsProc")){return 13;
	}else if (0==strcmp(name,"BiomassProc")){return 14;
	}else if (0==strcmp(name,"CommonMetalsProc")){return 15;
	}else if (0==strcmp(name,"RareMetalsProc")){return 16;
	}else if (0==strcmp(name,"ExoticMetalsProc")){return 17;
	}else if (0==strcmp(name,"RadioactivesProc")){return 18;
	}else if (0==strcmp(name,"FusionableGasesProc")){return 19;
	}else if (0==strcmp(name,"NeutroniumProc")){return 20;
        

	}else if (0==strcmp(name,"HeavyMan")){return 22;
	}else if (0==strcmp(name,"BiologicalMan")){return 23;
	}else if (0==strcmp(name,"WetwareMan")){return 24;
	}else if (0==strcmp(name,"HiTechMan")){return 25;
	}else if (0==strcmp(name,"ElectronicsMan")){return 26;
	}else if (0==strcmp(name,"WeaponsMan")){return 27;
	}else if (0==strcmp(name,"PharmaceuticalsMan")){return 28;
	}else if (0==strcmp(name,"PlasticsMan")){return 29;
	}else if (0==strcmp(name,"FusionReactorsMan")){return 30;
	}else if (0==strcmp(name,"EnergyCellsMan")){return 31;
	}else if (0==strcmp(name,"StationFabricationMan")){return 32;
	}else if (0==strcmp(name,"LuxuriesMan")){return 33;
        
	}else if (0==strcmp(name,"BioBomber")){return 35;
        
	}else if (0==strcmp(name,"Shipyard")){return 21;        
	}else if (0==strcmp(name,"Waystation")){return 36;

	}else if (0==strcmp(name,"Research")){return 40;
	}else if (0==strcmp(name,"MedicalResearch")){return 41;
	}else if (0==strcmp(name,"BlackResearch")){return 42;
	}else if (0==strcmp(name,"SensitiveResearch")){return 43;

	}else if (0==strcmp(name,"HQ")){return 45;
        
	}else if (0==strcmp(name,"AgSettlement")){return 48;

	}else if (0==strcmp(name,"Resort")){return 49;
	//}else if (0==strcmp(name,"LuxuryResort")){return 50;
        
	}else if (0==strcmp(name,"Medical")){return 51;

	}else if (0==strcmp(name,"SecurityStation")){return 54;
 	}else if (0==strcmp(name,"Fortress")){return 55;       
	}else if (0==strcmp(name,"MercenaryBase")){return 60;
        
	}else if (0==strcmp(name,"Warehousing")){return 62;
	}else if (0==strcmp(name,"Entertainment")){return 66;
        
	}else if (0==strcmp(name,"Settlement")){return 67;
	}else if (0==strcmp(name,"PoliceBase")){return 68;


	}else if (0==strcmp(name,"DefenceDock")){return 71;
        
	}else if (0==strcmp(name,"NavalAcademy")){return 72;

	}else if (0==strcmp(name,"NavalTraining")){return 73;

	}else if (0==strcmp(name,"MarineBarracks")){return 78;
        
	}else if (0==strcmp(name,"NavalResearch")){return 81;
        
	}else if (0==strcmp(name,"SupplyDepot")){return 84;


	//}else if (0==strcmp(name,"STC")){return 87;
        
	}else if (0==strcmp(name,"FTLArray")){return 88;

	}else if (0==strcmp(name,"STLTran")){return 90;


	}else if (0==strcmp(name,"SystemAdmin")){return 93;

	}else if (0==strcmp(name,"University")){return 96;


	}else if (0==strcmp(name,"PirateBase")){return 101;

	}else if (0==strcmp(name,"PirateCove")){return 102;

	}else if (0==strcmp(name,"PirateOutpost")){return 103;


	}else if (0==strcmp(name,"Casino")){return 106;

	}else if (0==strcmp(name,"Religious")){return 109;


	}else if (0==strcmp(name,"Habitat")){return 112;

	}else if (0==strcmp(name,"BoxTown")){return 114;

	}else if (0==strcmp(name,"JumpAccel")){return 118;
        
	}else if (0==strcmp(name,"Transfer")){return 122;}

	printf("Error: invalid station name n->t: %s\n",name);

	return 116;
}


int HabTypeToDef(int type)
{
	// one fighter wing
	int defense = 4;

	switch (type){
	case 54:
	case 87:
	case 101:
	case 102:
	case 68:
	case 40:
	case 41:
	case 74:
		// pair of patcoms
		defense = 2;
		break;
	case 55:
	case 60:
	case 71:
	case 42:
	case 43:
		// full wing of heavies
		defense = 4;
		break;
	}

	return defense;
}


int HabTypeToDefType(int type)
{
	// fighters by default
	int defense = 5;

	switch (type){
	case 54:
	case 87:
	case 101:
	case 102:
	case 68:
	case 40:
	case 41:
	case 74:
		// light combat stuff
		defense = 6;
		break;
	case 55:
	case 60:
	case 71:
	case 42:
	case 43:
		// heavy navy stuff
		defense = 7;
		break;
	}

	return defense;
}
