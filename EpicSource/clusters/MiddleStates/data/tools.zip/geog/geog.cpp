// g.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

// Entity type definition for stations and bodies
// 
typedef struct {
	unsigned char entity_type;
	char name[262];
	unsigned char seperator;
	double x_pos;
	double y_pos;
	double z_pos;
	float orient1;
	float orient2;
	float orient3;
	float y_scale;
	int parent_index;
	unsigned char body_model;
	unsigned char habitat_type;
	unsigned char faction_byte;
	unsigned char population;
	float body_radius;
	unsigned char texture_type;
	unsigned char planet_texture1;
	unsigned char planet_texture2;
	unsigned char unknown_a;
	float texture1_red;
	float texture1_green;
	float texture1_blue;
	float texture2_red;
	float texture2_green;
	float texture2_blue;
	float texture3_red;
	float texture3_green;
	float texture3_blue;
	unsigned char cloud_texture;
	unsigned char ring_number;
	unsigned char cloud_opacity;
	unsigned char unknown_c;
} Entity_T;

typedef struct {
	unsigned char entity_type;
	char name[262];
	unsigned char seperator;
	double x_pos;
	double y_pos;
	double z_pos;
	float orient1;
	float orient2;
	float orient3;
	float y_scale;
	int parent_index;
	int	parent_index2;
	unsigned char pad [46];
} JumpPoint_T;


typedef union all_union{
	Entity_T entity;
	JumpPoint_T jump;
} AllEntity_T;


typedef struct {
	int lpoint;
	char route[1024];

} JumpList_T;



void ParseCenter(Entity_T * data);
 
void ParseBody(Entity_T * data);
void ParseStar(Entity_T * data);
void ParseStation(Entity_T * data, FILE * finiout, int count);
void ParseNebula( Entity_T * data);
void ParseBelt( Entity_T * data);

void ParseLpoint(JumpPoint_T * data);
void ParseJumpRoute(JumpList_T * data);


void ParseName(char *name);
void ParseLocation(Entity_T * data, int parent);


int LookupParent(char * name);
void PlaceLpoint(JumpPoint_T * data);
void WriteJumpRoutes(FILE * foutput);
void ParseStationLocation(Entity_T * data, int parent, FILE * finiout, int count);

int HabTypeToDef(int type);
int HabTypeToDefType(int type);

/* 
	This global entity acts as symbol table
	and intermediate form for all objects in
	geography. When the *.csv file is done
	being parsed, this array is written to file
	to form the *.map file.

  */
AllEntity_T geog_array[1000];
int geog_entries;

JumpList_T jumps[100];
int jump_entries;

int main(int argc, char* argv[])
{
	FILE *finput = NULL;
	FILE *foutput = NULL;
	FILE *finiout = NULL;

	char line [2048];
	char * ptoken;
	char * cp;
	char value[4];
	int station_entries;

	//printf("Entity Size %d Jump Size %d All %d\n",sizeof(Entity_T),sizeof(JumpPoint_T),sizeof(AllEntity_T));

	// Clear entities
	memset(geog_array,0,1000*sizeof(AllEntity_T));
	geog_entries =0;
	
	memset(jumps,0,100*sizeof(JumpList_T));
	jump_entries =0;

	// Station INI files are now done by save_type
	// This program is strictly a converter.
	// 0 = command, 1 = input, 2 = map file
	if ( !(3 == argc)){
		//printf("Usage: geog <input spreadsheet name> <output map file name> <output station file>\n");
		printf("Usage: geog <input spreadsheet name> <output map file name> \n");
		return 1;
	}

	// Open the input file
	finput = fopen(argv[1],"r");

	if (NULL == finput){
		printf("Error: trying to open input file %s\n",argv[1]);
		return 1;
	}
		
	//if (4 == argc) {
	/*
		finiout = fopen(argv[3],"w");

		if (NULL == finiout){
			printf("Error: trying to open output station file %s\n",argv[3]);
			return 1;
		}

		fprintf(finiout,";\n;\n; Auto generated station ini file\n;\n;\n\n\n[starting_stations]\n");
	//}
	*/


	station_entries = 0;
	geog_entries = 0;

	// While not out of lines
	while (NULL != fgets(line,2048,finput)){

		ptoken = strtok(line, " \t,");
		//printf("token :%s:\n",ptoken);

		if (0 == strcmp("Body",ptoken)){
			ParseBody(&geog_array[geog_entries].entity);
			geog_entries++;
			
		}else if (0 == strcmp("Station",ptoken)){

			ParseStation(&geog_array[geog_entries].entity, finiout, station_entries);
			/*
			if (NULL == finiout){
				// if there is a station ini file, don't put the
				// stations in the geography files.
				geog_entries++;
			}
			*/
			geog_entries++;
			station_entries++;

		}else if (0 == strcmp("Lpoint",ptoken)){
			ParseLpoint(&geog_array[geog_entries].jump);

			jumps[jump_entries].lpoint = geog_entries;
			ParseJumpRoute(&jumps[jump_entries]);

			jump_entries++;
			geog_entries++;
			
		}else if (0 == strcmp("Belt", ptoken)){
			ParseBelt(&geog_array[geog_entries].entity);
			geog_entries++;

		}else if (0 == strcmp("Star", ptoken)){
			ParseStar(&geog_array[geog_entries].entity);
			geog_entries++;

		}else if (0 == strcmp("Gunstar", ptoken)){
			//geog_entries++;

		}else if (0 == strcmp("Nebula", ptoken)){
			ParseNebula(&geog_array[geog_entries].entity);
			geog_entries++;

		}else if (0 == strcmp("Center", ptoken)){
			ParseCenter(&geog_array[geog_entries].entity);
			geog_entries++;

		}else if (0 == strcmp("JumpRoute",ptoken)){
			ParseJumpRoute(&jumps[jump_entries]);
			jump_entries++;
		}
	}
	// Close input
	fclose(finput);

	//printf("Entries %d\n",geog_entries);


	// Write the hex file.

	foutput = fopen(argv[2],"w+b");

	if (NULL == foutput){
		printf("Error: trying to open output file %s\n",argv[2]);
		return 1;
	}



	// write the total records

	cp = (char *)&(geog_entries);
	value[0] = *(cp+3);
	value[1] = *(cp+2);	
	value[2] = *(cp+1);
	value[3] = *(cp);
	
	fwrite(&value,4,1,foutput);

	// write the entities
	fseek(foutput,4,SEEK_SET);

	//printf("Geog Ent %d\n",geog_entries);

	fwrite(&geog_array,sizeof(Entity_T),geog_entries,foutput);

	WriteJumpRoutes(foutput);

	// Close output
	fclose(foutput);

	return 0;
}




void ParseCenter( Entity_T * data)
{
	char name[512];
	// read the name, no whitespace.
	ParseName(name);
	strncpy(data->name,name,261);
	//printf("NTest b:%s: a:%s:\n",name, data->name);
	
	// only a few critical non-zero values
	data->orient1 = 1.0;
	data->orient2 = 0.0;
	data->orient3 = 0.0;

	// body entity type.
	data->entity_type= 0;
	data->body_model = 0;
	data->seperator = 0xd7;
}

void ParseStar( Entity_T * data)
{
	char token[512];
	char * ptoken;
	int star_type;

	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	//printf("Star :%s:\n",data->name);

	//printf("NTest b:%s: a:%s:\n",token, data->name);

	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	// Parse and place object
	ParseLocation(data, data->parent_index);

	// Parse star type
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&star_type);

	//printf("Star: parent %s type %d\n",token,star_type);

	data->entity_type= 5; // Type star
	data->body_model = star_type;
	data->seperator = 0xd7;
}

void ParseBody( Entity_T * data)
{
	char token[512];
	char * ptoken;
	int body_type, tex_type, tex1, tex2, population;
	int red, green, blue;
	int cloud_texture, cloud_opacity, rings;



	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	//printf("Body :%s:\n",data->name);

	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	// Parse and place object
	ParseLocation(data, data->parent_index);

	// Body type
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&body_type);

	// Population
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&population);

	data->body_model = body_type;
	data->population = population;


	// Texture type
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&tex_type);

	// Texture 1
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&tex1);

	// Texture 2
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&tex2);

	data->texture_type = tex_type;
	data->planet_texture1 = tex1;
	data->planet_texture2 = tex2;

	// Read texture 1 color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture1_red = (float)red;
	data->texture1_green = (float)green;
	data->texture1_blue = (float)blue;


	// Read texture 2 color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture2_red = (float)red;
	data->texture2_green = (float)green;
	data->texture2_blue = (float)blue;


	// Read cloud color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture3_red = (float)red;
	data->texture3_green = (float)green;
	data->texture3_blue = (float)blue;


	// Read cloud texture
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&cloud_texture);

	// Read rings 
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&rings);

	// Read cloud opacity
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&cloud_opacity);

	data->cloud_texture = cloud_texture;
	data->ring_number = rings;
	data->cloud_opacity = cloud_opacity;

	data->entity_type = 0; // Type body
	data->seperator = 0xd7;

}


void ParseStation(Entity_T * data,FILE* finiout, int count)
{
	char token[512];
	char * ptoken;
	int station_model, station_type, faction, population;


	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	//printf("Station :%s:\n",token);


	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	/*if (NULL != finiout){
		fprintf(finiout,"name[%d]=\"%s\"\n", count, data->name);
		fprintf(finiout,"parent_body[%d]=\"%s\"\n", count, token);
	}*/

	// Parse and place object
	ParseStationLocation(data, data->parent_index, finiout, count);

	// Parse model number
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&station_model);

	// Parse station type
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&station_type);

	// Parse faction number
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&faction);

	// Parse population
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&population);


	data->entity_type= 1; // Type station
	data->body_model = station_model;
	data->habitat_type = station_type;
	data->faction_byte = faction;
	data->population = population;
	data->seperator = 0xd7;

	/*if (NULL != finiout){
		fprintf(finiout,"type[%d]=%d\n", count, data->habitat_type);
		fprintf(finiout,"template[%d]=%d\n", count, data->body_model);
		fprintf(finiout,"faction[%d]=%d\n", count, data->faction_byte);

		fprintf(finiout,"defense[%d]=\"%d\"\n", count,HabTypeToDef(data->habitat_type));
		fprintf(finiout,"defense_type[%d]=\"%d\"\n\n\n", count,HabTypeToDefType(data->habitat_type));
		fprintf(finiout,"hidden[%d]=false\n", count, data->faction_byte);
		fprintf(finiout,"destroyed[%d]=false\n", count, data->faction_byte);
		fprintf(finiout,"visible[%d]=false\n", count, data->faction_byte);
	}*/
}


void ParseBelt( Entity_T * data)
{
	char token[512];

	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	//printf("Belt :%s:\n",data->name);

	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	// Parse and place object
	ParseLocation(data, data->parent_index);

	data->entity_type= 4; // Type belt
	data->seperator = 0xd7;
}




void ParseNebula( Entity_T * data)
{
	char token[512];
	char * ptoken;
	int body_type;
	int red, green, blue;


	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	//printf("Nebula :%s:\n",data->name);

	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	// Parse and place object
	ParseLocation(data, data->parent_index);

	// Body type
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&body_type);

	data->body_model = body_type;

	// Read texture 1 color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture1_red = (float)red;
	data->texture1_green = (float)green;
	data->texture1_blue = (float)blue;


	// Read texture 2 color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture2_red = (float)red;
	data->texture2_green = (float)green;
	data->texture2_blue = (float)blue;


	// Read cloud color triple
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&red);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&green);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&blue);

	data->texture3_red = (float)red;
	data->texture3_green = (float)green;
	data->texture3_blue = (float)blue;

	data->entity_type = 7; // Type Nebula
	data->seperator = 0xd7;

}








void ParseLpoint(JumpPoint_T * data)
{
	char token[512];

	data->entity_type = 2; // Type lpoint
	data->seperator = 0xd7;

	// Parse object name
	ParseName(token);
	strncpy(data->name,token,261);

	// Parse parent name
	ParseName(token);
	data->parent_index = LookupParent(token);

	// Parse second parent
	ParseName(token);
	data->parent_index2 = LookupParent(token);

	PlaceLpoint(data);

}

void ParseJumpRoute(JumpList_T * data)
{
	char token[512];
	char * ptoken;
	int entries, i, len;
	char * cp;

	// Read the number of entries
	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%d",&entries);

	// Read each entry, append to string.
	cp = data->route;
	for (i=0;i<entries;++i){
		ParseName(token);
		len = strlen(token);
		memcpy(cp,token,len);
		cp[len]=';';
		cp += len+1;
	}

	// If there are no entries, then just append one space
	// as required by the EOC engine.
	if (0 == entries){
		strcpy(cp," ");
	
	}
	//printf("JumpRoute loc %d route :%s: \n",data->lpoint,data->route);
}




int LookupParent(char * name)
{
	int i;

	for (i=0;i<geog_entries;++i){
		//printf("Store Name :%s:\n",geog_array[i].entity.name);
		if (0==strcmp(name,geog_array[i].entity.name)){
			// found the name, return the index.
			//printf("Found: %d\n",i);
			return i;
		}
	}

	printf("\n\nError: Parent %s not found. Parents must be listed before children. Possible typo\n",
			name);
	return 0;
}


void ParseLocation(Entity_T * data, int parent)
{
	char * ptoken;
	float dist, rot_x, rot_y, roll, pitch, yaw, y_scale, radius;
	double x, y, z, dist2, x_rad, y_rad;
	Entity_T * pparent;

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&dist);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&rot_x);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&rot_y);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&roll);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&pitch);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&yaw);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&y_scale);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&radius);

	// Convert rotational coordinates into vector notation
	y_rad = ((rot_y * 2.0 * 3.14159)/360.0);
	x_rad = ((rot_x * 2.0 * 3.14159)/360.0);

	y = sin(y_rad)*dist;
	dist2 = cos(y_rad)*dist;
	x = cos(x_rad)*dist2;
	z = sin(x_rad)*dist2;

	pparent = &geog_array[parent].entity;

	// Add to parent position, to find final position.
	data->x_pos = x	+ pparent->x_pos;
	data->y_pos = y + pparent->y_pos;
	data->z_pos = z + pparent->z_pos;

	
	// calculate orientation
	
	data->orient1 = roll;
	data->orient2 = pitch;
	data->orient3 = yaw;

	/*
	data->orient1 = 1.0;
	data->orient2 = 0.0;
	data->orient3 = 0.0;
*/
	// set radius and y scale factor
	data->body_radius = radius;
	data->y_scale = y_scale;

	//printf("Location d %f, xr %f, yr %f, r %f, p %f, y %f, sc %f, rad %f \n", dist, rot_x, rot_y, roll, pitch, yaw, y_scale, radius);

	//printf("Calc Loc x %f, y %f, z %f \n",data->x_pos, data->y_pos, data->z_pos);
}


void ParseStationLocation(Entity_T * data, int parent, FILE * finiout, int count)
{
	char * ptoken;
	float dist, rot_x, rot_y, roll, pitch, yaw, y_scale, radius;
	double x, y, z, dist2, x_rad, y_rad;
	Entity_T * pparent;

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&dist);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&rot_x);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&rot_y);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&roll);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&pitch);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&yaw);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&y_scale);

	ptoken = strtok(NULL," \t,");
	sscanf(ptoken,"%f",&radius);

	/*if (NULL != finiout){

		fprintf(finiout,"orbital_distance[%d]=%f\n",count,dist);
		fprintf(finiout,"orbital_angle_around[%d]=%f\n",count,rot_x);
		fprintf(finiout,"orbital_angle_above[%d]=%f\n",count,rot_y);
	}*/

	// Convert rotational coordinates into vector notation
	y_rad = ((rot_y * 2.0 * 3.14159)/360.0);
	x_rad = ((rot_x * 2.0 * 3.14159)/360.0);

	y = sin(y_rad)*dist;
	dist2 = cos(y_rad)*dist;
	x = cos(x_rad)*dist2;
	z = sin(x_rad)*dist2;

	pparent = &geog_array[parent].entity;

	// Add to parent position, to find final position.
	data->x_pos = x	+ pparent->x_pos;
	data->y_pos = y + pparent->y_pos;
	data->z_pos = z + pparent->z_pos;

	
	// calculate orientation
	
	data->orient1 = roll;
	data->orient2 = pitch;
	data->orient3 = yaw;

	/*
	data->orient1 = 1.0;
	data->orient2 = 0.0;
	data->orient3 = 0.0;
*/
	// set radius and y scale factor
	data->body_radius = radius;
	data->y_scale = y_scale;

	//printf("Location d %f, xr %f, yr %f, r %f, p %f, y %f, sc %f, rad %f \n", dist, rot_x, rot_y, roll, pitch, yaw, y_scale, radius);

	//printf("Calc Loc x %f, y %f, z %f \n",data->x_pos, data->y_pos, data->z_pos);
}


void PlaceLpoint(JumpPoint_T * data)
{
	Entity_T * moon;
	Entity_T * planet;

	double vecx, vecy, vecz, dist, x, y, z, degree;

	moon = &geog_array[data->parent_index].entity;
	planet = &geog_array[data->parent_index2].entity;

	vecx = moon->x_pos - planet->x_pos;
	vecy = moon->y_pos - planet->y_pos;
	vecz = moon->z_pos - planet->z_pos;

	// find vector length.
	dist = sqrt(vecx*vecx+vecy*vecy+vecz*vecz);

	// find unit vector
	x = vecx/dist;
	y = vecy/dist;
	z = vecz/dist;

	// find the lpoint location, halfway between the two parents

	vecx = x*dist*0.5 + planet->x_pos;
	vecy = y*dist*0.5 + planet->y_pos;
	vecz = z*dist*0.5 + planet->z_pos;

	// fill the lpoint entries

	degree = (45.0 + (fabs(z)*15.0))*3.14159/180.0;


	/* ccw rotation */
	data->orient1 = (float)(x*cos(degree)-z*sin(degree));
	data->orient2 = (float)y;
	data->orient3 = (float)(x*sin(degree)+z*cos(degree));
	
	data->x_pos = vecx;
	data->y_pos = vecy;
	data->z_pos = vecz;

	//printf("Lpoint vector x %f, y %f, z %f\n",x, y, z);
	//printf("Lpoint orient x %f, y %f, z %f\n",data->orient1, data->orient2, data->orient3);
}


void ParseName(char * name)
{
	char temp[1024];
	char * ptoken;
	int length, i;

	// finds name, but has white space lead and trail.
	ptoken = strtok(NULL, ",");

	// get the tokenizer out of the equation.
	strcpy(temp,ptoken);
	ptoken = temp;

	// find lead without space, and skip
	//lead = strspn(ptoken," ");
	//ptoken += lead;

	length = strlen(ptoken);
	for (i=0;i<length;i++,ptoken++)
	{
		if (!isspace(*ptoken)){
			break;
		}
	}
	
	length = strlen(ptoken);

	for (i=length-1;i>0;--i){
		if (!isspace(ptoken[i])){
			strncpy(name,ptoken,i+1);
			name[i+1]=0;
			//printf("Name :%s: %d\n",name,i);
			return;
		}
	}

	name[0]=0;
}

void WriteJumpRoutes(FILE * foutput)
{
	char * cp;
	int i;
	short len;
	char temp, junk[50];
	
	//printf("Jumps %d \n",jump_entries);

	// write the strange header block
	memset(junk,0,50);
	junk[3]=0x11;
	junk[7]=0x11;
	fwrite(junk,1,8,foutput);

	// write the number of entries
	cp = (char *)&jump_entries;
	fwrite(cp+3,1,1,foutput);
	fwrite(cp+2,1,1,foutput);
	fwrite(cp+1,1,1,foutput);
	fwrite(cp+0,1,1,foutput);

	for (i=0;i<jump_entries;++i){

		// Reverse the index and write to 
		// the buffer
		cp = (char *)&(jumps[i].lpoint);
		fwrite(cp+3,1,1,foutput);
		fwrite(cp+2,1,1,foutput);
		fwrite(cp+1,1,1,foutput);
		fwrite(cp+0,1,1,foutput);	
		
		// write two fixed bytes
		temp = (char)0x80;
		fwrite(&temp,1,1,foutput);
		temp = 0x00;
		fwrite(&temp,1,1,foutput);

		// write two string length bytes, reversed
		len = strlen(jumps[i].route);
		len++;
		cp = (char *)&(len);
		fwrite(cp+1,1,1,foutput);
		fwrite(cp+0,1,1,foutput);

		// write the string, including null.
		fwrite(jumps[i].route,1,len,foutput);

		//printf("Route :%s:\n",jumps[i].route);
	}
}


int HabTypeToDef(int type)
{
	// one fighter wing
	int defense = 4;

	switch (type){
	case 54:
	case 87:
	case 101:
	case 102:
	case 68:
	case 40:
	case 41:
	case 74:
		// pair of patcoms
		defense = 2;
		break;
	case 55:
	case 60:
	case 71:
	case 42:
	case 43:
		// full wing of heavies
		defense = 4;
		break;
	}

	return defense;
}


int HabTypeToDefType(int type)
{
	// fighters by default
	int defense = 5;

	switch (type){
	case 54:
	case 87:
	case 101:
	case 102:
	case 68:
	case 40:
	case 41:
	case 74:
		// light combat stuff
		defense = 6;
		break;
	case 55:
	case 60:
	case 71:
	case 42:
	case 43:
		// heavy navy stuff
		defense = 7;
		break;
	}

	return defense;
}

/*
		if (0 == strcmp("SystemCentre",token)){
			
		}else if (0 == strcmp("Star",token)){

		}else if (0 == strcmp("Planet",token)){
			
		}else if (0 == strcmp("Moon", token)){

		}else if (0 == strcmp("GasGiant", token)){

		}else if (0 == strcmp("Asteroid", token)){

		}else if (0 == strcmp("DeadGasGiantCore", token)){

		}else if (0 == strcmp("AsteroidBelt", token)){

		}else if (0 == strcmp("Nebula",token)){

		}else if (0 == strcmp("Lpoint",token

*/

/*

Each entity gets a line in the spreadsheet. All values must be on the same line.

Text description of the input spreadsheet for each entity

string			entity type
string			name

float			dist from parent
float			rot around parent
float			rot above parent
float			roll 
float			pitch 
float			yaw
float			y_scale
float			body radius

string			parent
string			body type 

int             station model number (ignored for non station)
int				habitat type 
int				faction number
int				total population 
int				texture type

int				first planet texture index
int				second planet texture index
int				unknown texture index

int				first texture red
int				first texture green
int				first texture blue
int				second texture red
int				second texture green
int				second texture blue
int				unknown red
int				unknown blue
int				unknown green

int				cloud texture index
int				number of rings (max 8)
int				unknown
int				unknown


Jump routes are special entities.

int				jump route entity type (new value)
int				hidden? 0 = no, 1 = yes
int				known? 0 = no, 1 = yes
string			name of destination1
string			name of destinationN until no more

destination names end at end of line.

*/
/*

Geography .map notes:
byte 0-3 = number of entities in .map package (includes system entity and main star) big endian long

for each entity:
byte 0 = entity type ( see list 1 )
byte 1-263 = ASCII string, entity name (terminates in first 00, rest is meaningless filler ending in D7)
byte 264-271 = xvalue double-float
byte 272-279 = yvalue double-float
byte 280-287 = zvalue double-float
byte 288-291 = orientation1 float
byte 292-295 = orientation2 float
byte 296-299 = orientation3 float
byte 300-303 = yscale float
byte 304-307 = parent long
byte 308 = body type byte (see list 2) OR habitat model
byte 309 = habitat type (see list 3) byte
byte 310 = habitat faction byte
byte 311 = population
byte 312-315 = body radius float
byte 316 = texture type (see list 6)
byte 317 = planet texture1 byte
byte 318 = planet texture2 byte
byte 319 = unknown
byte 320-323 = first texture red float
byte 324-327 = first texture green float
byte 328-331 = first texture blue float
byte 332-335 = second texture red float
byte 336-339 = second texture green float
byte 340-343 = second texture blue float
byte 344-347 = unknown color red float
byte 348-351 = unknown color green float
byte 352-355 = unknown color blue float
byte 356 = cloud texture byte (ff = no clouds)
byte 357 = ring number
byte 358 = cloud opacity?
byte 359 = unknown


beginning of lpoint section at bottom of file:
byte 0-7 = unknown, usually 0000 0011 0000 0011 (probably marker for beginning of lpoints)
byte 8-11 = # of lpoint entries motorola long

each lpoint entry:
byte 0-3 = lpoint reference motorola long
byte 4-5 = unknown, always "80 00"
byte 6-7 = X# of destination bytes including null at end, short
following X bytes = destination references (for interstellar, destination is string name followed by ; ex:"hoffers_wake;" end destinations with a 00)
	(for non interstellar lpoints, destination length is "02" and destination is "20 00" )

LIST 1 entity types (byte 0):
00 = Body - Also system center, but not star
01 = Station
02 = Lpoint
03 = Unused
04 = Belt
05 = Star
06 = Gunstar
07 = Nebula

LIST 2 body types (byte 308):
enum IeBodyType 
{ 
BT_SystemCentre = 0, 
BT_Star = 1, 
BT_Planet = 2, 
BT_Moon = 3, 
BT_GasGiant = 4, 
BT_Asteroid = 5, 
BT_DeadGasGiantCore = 6, 
BT_AsteroidBelt = 7, 
BT_Nebula = 8, 
BT_Invalid = 9 
};

SystemCentre = 0, 
Star = 1, 
Planet = 2, 
Moon = 3, 
GasGiant = 4, 
Asteroid = 5, 
DeadGasGiantCore = 6, 
AsteroidBelt = 7, 
Nebula = 8,


Body type becomes star color type, when entity is a star.
1 - Blue 
2 - Bluish white 
5 - Yellow 
8 - Red with a touch of orange 
9 - Red 
11 - Deep, almost blood red 

Batatas M0_V 
Coyote G8_V 
Dagda M0_V 
Dante I F3_V 



Coyote G8_V 
Eureka G1_V 
Firefrost I G0_I 
Mwari II G0_V 
Santa Romera G5_V 

Drake K4_V 
Firefrost II K1_V 
Dante II K7_V 
Kompira K0_V 
Osprey K4_V 

Firefrost III M0_V 
Hoffer's Wake Alpha M0_V 
New Bavaria M7_V 
Ishme M7_V 
Owen's Star M9_V 

Formhault A3_V 

Hoffer's Wake Beta F5_V 
Mwari I F5_V 



V is main sequence, I is giant.

OBAFGKM

1	O blue
2	B blue-white
3	A white
4	F yellow-white
5	G yellow
6	K orange
7	M red
8	
9	
10
11	

for each Star:
byte 0 = entity type ( see list 1 )
byte 1-263 = ASCII string, entity name (terminates in first 00, rest is meaningless filler ending in D7)
byte 264-271 = xvalue double-float
byte 272-279 = yvalue double-float
byte 280-287 = zvalue double-float
byte 288-291 = orientation1 float
byte 292-295 = orientation2 float
byte 296-299 = orientation3 float
byte 300-303 = yscale float
byte 304-307 = parent long - always system center
byte 308 = star color type 
byte 309 = 0
byte 310 = 0
byte 311 = 0
byte 312-315 = body radius float
byte 316 - 359 = 0


for each jump route:
byte 0 = entity type ( see list 1 )
byte 1-263 = ASCII string, entity name (terminates in first 00, rest is meaningless filler ending in D7)
byte 264-271 = xvalue double-float
byte 272-279 = yvalue double-float
byte 280-287 = zvalue double-float
byte 288-291 = orientation1 float
byte 292-295 = orientation2 float
byte 296-299 = orientation3 float
byte 300-303 = yscale float
byte 304-307 = parent long
byte 308-311 = parent 2 long
byte 312-359 = 0


LIST 6 texture type
1 to use rocky planet textures
2 to use gas giant planet textures


LIST 3 station types (byte 309):
enum IeHabitatType
{
	HT_Invalid = 0,
	HT_Disused = 1,
	HT_WaterMine = 2,
	HT_OrganicsMine = 3,
	HT_InorganicsMine = 4,
	HT_BiomassMine = 5,
	HT_CommonMetalsMine = 6,
	HT_RareMetalsMine = 7,
	HT_ExoticMetalsMine = 8,
	HT_RadioactivesMine = 9,
	HT_FusionableGasesMine = 10,
	HT_WaterProcessingPlant = 11,
	HT_OrganicsProcessingPlant = 12,
	HT_InorganicsProcessingPlant = 13,
	HT_BiomassProcessingPlant = 14,
	HT_CommonMetalsProcessingPlant = 15,
	HT_RareMetalsProcessingPlant = 16,
	HT_ExoticMetalsProcessingPlant = 17,
	HT_RadioactivesProcessingPlant = 18,
	HT_FusionableGasesProcessingPlant = 19,
	HT_NeutroniumProcessingPlant = 20,
	HT_Shipyard = 21,
	HT_HeavyManufacturingPlant = 22,
	HT_BiologicalManufacturingPlant = 23,
	HT_WetwareManufacturingPlant = 24,
	HT_HiTechManufacturingPlant = 25,
	HT_ElectronicsManufacturingPlant = 26,
	HT_WeaponsManufacturingPlant = 27,
	HT_PharmaceuticalsManufacturingPlant = 28,
	HT_PlasticsManufacturingPlant = 29,
	HT_FusionReactorsManufacturingPlant = 30,
	HT_EnergyCellsManufacturingPlant = 31,
	HT_StationFabricationManufacturingPlant = 32,
	HT_LuxuriesManufacturingPlant = 33,
	HT_TerraformingStation = 34,
	HT_BioBomber = 35,
	HT_Waystation = 36,
	HT_RepairStation = 37,
	HT_OreTransferStation = 38,
	HT_ResearchAndDevelopmentLab = 39,
	HT_ResearchStation = 40,
	HT_MedicalResearchCentre = 41,
	HT_BlackBudgetResearchStation = 42,
	HT_SensitiveResearchStation = 43,
	HT_FinancialCentre = 44,
	HT_RegionalHQ = 45,
	HT_Villa = 46,
	HT_CentralHQ = 47,
	HT_AgriculturalSettlement = 48,
	HT_Resort = 49,
	HT_LuxuryResort = 50,
	HT_MedicalFacility = 51,
	HT_LeisureComplex = 52,
	HT_NeutroniumMine = 53,
	HT_SecurityStation = 54,
	HT_Fortress = 55,
	HT_HighSecurityPrison = 56,
	HT_LowSecurityPrison = 57,
	HT_HardLabourPrison = 58,
	HT_Homestead = 59,
	HT_MercenaryBase = 60,
	HT_TradingPost = 61,
	HT_Warehousing = 62,
	HT_BlackMarket = 63,
	HT_DryDock = 64,
	HT_DockingStation = 65,
	HT_EntertainmentStation = 66,
	HT_Settlement = 67,
	HT_PoliceBase = 68,
	HT_PoliceOutpost = 69,
	HT_SystemDefenceStation = 70,
	HT_SystemDefenceDock = 71,
	HT_NavalAcademy = 72,
	HT_NavalTrainingBase = 73,
	HT_Outpost = 74,
	HT_Base = 75,
	HT_RepairDock = 76,
	HT_MarineBarracks = 78,
	HT_PerimeterDefences = 79,
	HT_NavalTestingSite = 80,
	HT_NavalResearchFacility = 81,
	HT_JumpFortress = 82,
	HT_SupplyDepot = 84,
	HT_DefenceStation = 85,
	HT_STCPost = 86,
	HT_STCHQ = 87,
	HT_FTLArray = 88,
	HT_FTLInterchange = 89,
	HT_STLTranceiver = 90,
	HT_STLInterchange = 91,
	HT_PlanetaryAdministration = 92,
	HT_SystemAdministration = 93,
	HT_ClusterAdministration = 94,
	HT_RegionalDepartment = 95,
	HT_University = 96,
	HT_Ark = 97,
	HT_Garden = 98,
	HT_Asylum = 99,
	HT_Hospice = 100,
	HT_PirateBase = 101,
	HT_PirateCove = 102,
	HT_PirateOutpost = 103,
	HT_GangsterHideout = 104,
	HT_ViceDen = 105,
	HT_Casino = 106,
	HT_CollectiveSettlement = 107,
	HT_Hermitage = 108,
	HT_ReligiousCentre = 109,
	HT_MadScientistLab = 110,
	HT_Hideout = 111,
	HT_Habitat = 112,
	HT_Junkyard = 113,
	HT_BoxTown = 114,
	HT_AsteroidSculptures = 115,
	HT_PlayerBase = 116,
	HT_GunstarArray = 117,
	HT_JumpAccelerator = 118,
	HT_HoffersGap = 119,
	HT_HoffersHeel = 120,
	HT_Beanstalk = 121,
	HT_TransferStation = 122

};

LIST 4 factions (byte 310);
enum IeAllegiance
{
	A_Neutral = 00,
	A_Independent = 01,
	A_Exile = 02,
	A_Military = 03,
	A_Underworld = 04,
	A_Government = 05,
	A_Transient = 06,
	A_Society = 07,
    A_Invalid = 08,
	A_Stepson = 09,
	A_Kong = 0a,
	A_MAASCorporation = 0b,
	A_CarvaCartel = 0c,
	A_Junkers = 0d,
	A_Police = 0e,
	A_NOMEXCorporation = 0f,
	A_NSOLaplace = 10,
	A_Marauders = 11,
	A_Angels = 12,
	A_TheOman = 13,
	A_MCA = 14,
	A_Player = 15,
	A_League = 16,
	A_TrimannShipping = 17,
	A_RhondusGasMining = 18,
	A_AshantiInvestment = 19,
	A_CrosspointMinerals = 1a,
	A_HeliosMining = 1b,
	A_JardinTerraforming = 1c,
	A_ChonBodifule = 1d,
	A_OrionProducts = 1e,
	A_VonShellingIndustries = 1f,
	A_MegalithCorp = 20,
	A_HibatshPMC = 21,
	A_DesterCorporation = 22,
	A_WhindWeaponsSystems = 23,
	A_AdvancedSecurityCorp = 24,
	A_Network54 = 25,
	A_Infonet = 26,
	A_StellarNet = 27,
	A_WordsworthTechnology = 28,
	A_NetcomSA = 29,
	A_CoventryEngineeringResearch = 2a,
	A_NINEXWetware = 2b,
	A_UniversalConsumerProducts = 2c,
	A_HighlifeProducts = 2d,
	A_LowOrbitRecovery = 2e,
	A_KIMOShipping = 2f,
	A_DatagonTechnologies = 30,
	A_MicoriaCommunications = 31,
	A_LOMAXEngines = 32,
	A_LOMAXTechnologies = 33,
	A_NumikoProducts = 34,
	A_TheThirdWay = 35,
	A_Aliens = 36,
	eIeAllegianceCount
};

LIST 5 rings (byte 316);
01 = no rings
02 = rings


  */